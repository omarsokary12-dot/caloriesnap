//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DwbWmX6s.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DxgAcmSQ.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DxgAcmSQ.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-NpBTs3jS.js"]
	}
} });
//#endregion
export { tsrStartManifest };
