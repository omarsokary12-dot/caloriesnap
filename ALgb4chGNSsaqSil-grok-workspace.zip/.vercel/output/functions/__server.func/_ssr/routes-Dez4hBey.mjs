import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, q as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as Leaf, i as Send, o as Camera, r as Trash2, t as X } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Dez4hBey.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var analyzeMeal = createServerFn({ method: "POST" }).validator((input) => {
	const text = (input.text ?? "").trim().slice(0, 800);
	const imageDataUrl = input.imageDataUrl ?? null;
	if (!text && !imageDataUrl) throw new Error("Add a photo or describe the meal.");
	if (imageDataUrl && imageDataUrl.length > 18e5) throw new Error("That photo is too large. Try a smaller one.");
	if (imageDataUrl && !imageDataUrl.startsWith("data:image/")) throw new Error("Only image uploads are supported.");
	return {
		text,
		imageDataUrl
	};
}).handler(createSsrRpc("2186f1e51d2951eb0d0d8be00947e482328cc85c0135d45d733c8338aaef039d"));
var WELCOME = {
	id: "welcome",
	role: "assistant",
	text: "Send a photo of a meal, or type what you ate. I’ll estimate calories plus protein, carbs, and fat. Portions from a photo are always approximate."
};
function Home() {
	const [messages, setMessages] = (0, import_react.useState)([WELCOME]);
	const [draft, setDraft] = (0, import_react.useState)("");
	const [preview, setPreview] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const scroller = (0, import_react.useRef)(null);
	const fileRef = (0, import_react.useRef)(null);
	const boxRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		scroller.current?.scrollTo({
			top: scroller.current.scrollHeight,
			behavior: "smooth"
		});
	}, [messages, busy]);
	async function onFile(file) {
		if (!file) return;
		if (!file.type.startsWith("image/")) {
			setError("Choose a photo.");
			return;
		}
		setError(null);
		const dataUrl = await compressImage(file);
		setPreview(dataUrl);
	}
	async function send() {
		const text = draft.trim();
		if (busy || !text && !preview) return;
		setBusy(true);
		setError(null);
		const image = preview;
		const userMsg = {
			id: crypto.randomUUID(),
			role: "user",
			text: text || "Meal photo",
			image: image ?? void 0
		};
		setMessages((prev) => [...prev, userMsg]);
		setDraft("");
		setPreview(null);
		if (boxRef.current) boxRef.current.style.height = "auto";
		try {
			const result = await analyzeMeal({ data: {
				text,
				imageDataUrl: image
			} });
			setMessages((prev) => [...prev, {
				id: crypto.randomUUID(),
				role: "assistant",
				text: result.ok ? result.text : result.error
			}]);
			if (!result.ok) setError(result.error);
		} catch (err) {
			const message = err instanceof Error ? err.message : "Something went wrong.";
			setError(message);
			setMessages((prev) => [...prev, {
				id: crypto.randomUUID(),
				role: "assistant",
				text: message
			}]);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex h-dvh max-w-2xl flex-col px-4 py-4 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mb-3 flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex size-11 items-center justify-center rounded-2xl bg-primary text-primary-fg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Leaf, {
							className: "size-5",
							"aria-hidden": true
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-2xl leading-none tracking-tight",
						children: "CalorieSnap"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Photo in, calorie estimate out"
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "flex size-11 items-center justify-center rounded-2xl border border-line bg-surface text-ink",
					"aria-label": "Clear chat",
					onClick: () => {
						setMessages([WELCOME]);
						setError(null);
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				ref: scroller,
				className: "min-h-0 flex-1 space-y-3 overflow-y-auto pb-3",
				children: [messages.map((msg) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: msg.role === "user" ? "ml-10 rounded-3xl rounded-br-md bg-user px-4 py-3 text-user-fg" : "mr-8 rounded-3xl rounded-bl-md border border-line bg-surface px-4 py-3 text-ink",
					children: [msg.image ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: msg.image,
						alt: "Meal you uploaded",
						className: "mb-2 max-h-52 w-full rounded-2xl object-cover"
					}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "whitespace-pre-wrap text-[15px] leading-relaxed",
						children: msg.text
					})]
				}, msg.id)), busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mr-8 rounded-3xl border border-line bg-surface px-4 py-3 text-sm text-muted",
					children: "Looking at the meal…"
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "rounded-3xl border border-line bg-surface p-3 shadow-sm",
				onSubmit: (e) => {
					e.preventDefault();
					send();
				},
				children: [
					preview ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative mb-3 inline-block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: preview,
							alt: "Selected meal",
							className: "h-20 w-20 rounded-2xl object-cover"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "absolute -top-2 -right-2 flex size-7 items-center justify-center rounded-full bg-ink text-user-fg",
							"aria-label": "Remove photo",
							onClick: () => setPreview(null),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" })
						})]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-end gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "flex size-11 shrink-0 items-center justify-center rounded-2xl bg-bg text-ink",
								"aria-label": "Upload meal photo",
								onClick: () => fileRef.current?.click(),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "size-5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								ref: fileRef,
								type: "file",
								accept: "image/*",
								className: "hidden",
								onChange: (e) => {
									onFile(e.target.files?.[0]);
									e.target.value = "";
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								ref: boxRef,
								rows: 1,
								value: draft,
								placeholder: "Describe the meal, or just send a photo",
								className: "max-h-32 min-h-11 flex-1 resize-none bg-transparent px-1 py-2.5 text-[15px] outline-none placeholder:text-muted",
								onChange: (e) => {
									setDraft(e.target.value);
									e.target.style.height = "auto";
									e.target.style.height = `${Math.min(e.target.scrollHeight, 128)}px`;
								},
								onKeyDown: (e) => {
									if (e.key === "Enter" && !e.shiftKey) {
										e.preventDefault();
										send();
									}
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "submit",
								disabled: busy || !draft.trim() && !preview,
								className: "flex size-11 shrink-0 items-center justify-center rounded-2xl bg-primary text-primary-fg disabled:opacity-40",
								"aria-label": "Send",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-4" })
							})
						]
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 px-1 text-sm text-danger",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 px-1 text-xs text-muted",
						children: "Estimates only. Not medical advice."
					})
				]
			})
		]
	});
}
function compressImage(file) {
	return new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onerror = () => reject(/* @__PURE__ */ new Error("Could not read that photo."));
		reader.onload = () => {
			const img = new Image();
			img.onload = () => {
				const scale = Math.min(1, 1024 / Math.max(img.width, img.height));
				const canvas = document.createElement("canvas");
				canvas.width = Math.round(img.width * scale);
				canvas.height = Math.round(img.height * scale);
				const ctx = canvas.getContext("2d");
				if (!ctx) {
					reject(/* @__PURE__ */ new Error("Could not prepare that photo."));
					return;
				}
				ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
				resolve(canvas.toDataURL("image/jpeg", .72));
			};
			img.onerror = () => reject(/* @__PURE__ */ new Error("That file is not a usable photo."));
			img.src = String(reader.result);
		};
		reader.readAsDataURL(file);
	});
}
//#endregion
export { Home as component };
