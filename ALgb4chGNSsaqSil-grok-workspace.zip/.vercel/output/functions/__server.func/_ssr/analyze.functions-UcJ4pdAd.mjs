import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/analyze.functions-UcJ4pdAd.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var SYSTEM = `You are CalorieSnap, a nutrition assistant.
Estimate calories from a meal photo and/or a short description.
Reply in plain text (no markdown tables). Include:
1) What you see (foods and a reasonable portion guess)
2) Estimated calories (a single number plus a short range)
3) Protein, carbs, and fat in grams
4) One practical tip
Be honest when the photo is unclear or portion size is uncertain.
This is an estimate, not medical advice. Keep the reply under 180 words.`;
var analyzeMeal_createServerFn_handler = createServerRpc({
	id: "2186f1e51d2951eb0d0d8be00947e482328cc85c0135d45d733c8338aaef039d",
	name: "analyzeMeal",
	filename: "src/lib/analyze.functions.ts"
}, (opts) => analyzeMeal.__executeServer(opts));
var analyzeMeal = createServerFn({ method: "POST" }).validator((input) => {
	const text = (input.text ?? "").trim().slice(0, 800);
	const imageDataUrl = input.imageDataUrl ?? null;
	if (!text && !imageDataUrl) throw new Error("Add a photo or describe the meal.");
	if (imageDataUrl && imageDataUrl.length > 18e5) throw new Error("That photo is too large. Try a smaller one.");
	if (imageDataUrl && !imageDataUrl.startsWith("data:image/")) throw new Error("Only image uploads are supported.");
	return {
		text,
		imageDataUrl
	};
}).handler(analyzeMeal_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "AI is not available in this environment."
	};
	const content = [];
	content.push({
		type: "text",
		text: data.text || "Estimate the calories in this meal photo."
	});
	if (data.imageDataUrl) content.push({
		type: "image_url",
		image_url: {
			url: data.imageDataUrl,
			detail: "high"
		}
	});
	const res = await fetch("https://api.x.ai/v1/chat/completions", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		body: JSON.stringify({
			model: "grok-4.5",
			temperature: .3,
			max_tokens: 450,
			messages: [{
				role: "system",
				content: SYSTEM
			}, {
				role: "user",
				content
			}]
		})
	});
	if (!res.ok) {
		const body = await res.text().catch(() => "");
		return {
			ok: false,
			error: `Could not analyze that meal (${res.status}). ${body.slice(0, 180)}`
		};
	}
	const text = (await res.json()).choices?.[0]?.message?.content?.trim();
	if (!text) return {
		ok: false,
		error: "No estimate came back. Try again."
	};
	return {
		ok: true,
		text
	};
});
//#endregion
export { analyzeMeal_createServerFn_handler };
