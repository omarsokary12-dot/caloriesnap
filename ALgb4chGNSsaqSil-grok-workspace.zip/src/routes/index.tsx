import { createFileRoute } from "@tanstack/react-router";
import { BarChart3, Camera, Leaf, Send, Trash2, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { analyzeMeal } from "@/lib/analyze.functions";

export const Route = createFileRoute("/")({ component: Home });

type ChatMessage = {
  id: string;
  role: "user" | "assistant";
  text: string;
  image?: string;
};

const WELCOME: ChatMessage = {
  id: "welcome",
  role: "assistant",
  text: "Send a photo of a meal, or type what you ate. I’ll estimate calories plus protein, carbs, and fat. Today’s total stays on this phone.",
};

type DayLog = { id: string; label: string; kcal: number };

function todayKey() {
  const d = new Date();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${d.getFullYear()}-${m}-${day}`;
}

function readStore(): { goal: number; items: DayLog[]; history: Record<string, number> } {
  try {
    const raw = localStorage.getItem("caloriesnap-day");
    const parsed = raw
      ? (JSON.parse(raw) as {
          goal?: number;
          day?: string;
          items?: DayLog[];
          history?: Record<string, number>;
        })
      : {};
    const day = todayKey();
    return {
      goal: parsed.goal && parsed.goal > 0 ? parsed.goal : 2000,
      items: parsed.day === day && Array.isArray(parsed.items) ? parsed.items : [],
      history: parsed.history && typeof parsed.history === "object" ? parsed.history : {},
    };
  } catch {
    return { goal: 2000, items: [], history: {} };
  }
}

function weekDays() {
  const days: { key: string; label: string }[] = [];
  const now = new Date();
  for (let i = 6; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(now.getDate() - i);
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    days.push({
      key: `${d.getFullYear()}-${m}-${day}`,
      label: d.toLocaleDateString(undefined, { weekday: "short" }),
    });
  }
  return days;
}

type Profile = { age: string; weight: string; height: string; sex: "m" | "f"; goalWeight: string };

function targets(profile: Profile): { kcal: number; protein: number; note: string } | null {
  const age = Number(profile.age);
  const kg = Number(profile.weight);
  const cm = Number(profile.height);
  const goalKg = Number(profile.goalWeight);
  if (age < 10 || age > 100 || kg < 30 || kg > 300 || cm < 100 || cm > 250) return null;
  if (!goalKg || goalKg < 30 || goalKg >= kg) return null;
  const bmr = 10 * kg + 6.25 * cm - 5 * age + (profile.sex === "m" ? 5 : -161);
  const maintain = bmr * 1.4;
  const lose = kg - goalKg;
  const perWeek = lose / 13;
  const wanted = (lose * 7700) / 90;
  const deficit = Math.min(wanted, 750);
  const floor = profile.sex === "m" ? 1500 : 1200;
  const kcal = Math.max(floor, Math.round(maintain - deficit));
  const protein = Math.round(kg * 1.6);
  const note =
    wanted > 750
      ? `${lose.toFixed(1)} kg in 3 months is faster than a steady plan. Eat ${kcal} kcal a day (about 0.7 kg a week). You may need longer than 3 months.`
      : `Lose ${lose.toFixed(1)} kg in 3 months, about ${perWeek.toFixed(1)} kg a week. Eat ${kcal} kcal and ${protein} g protein a day.`;
  return { kcal, protein, note };
}

function kcalFrom(text: string): number | null {
  const match = text.match(/(\d[\d,]*)\s*kcal/i);
  if (!match) return null;
  const n = Number(match[1].replace(/,/g, ""));
  return Number.isFinite(n) && n > 0 && n < 8000 ? n : null;
}

function WeekPanel({
  goal,
  items,
  history,
}: {
  goal: number;
  items: DayLog[];
  history: Record<string, number>;
}) {
  const today = todayKey();
  const rows = weekDays().map((day) => ({
    ...day,
    kcal: day.key === today ? items.reduce((n, item) => n + item.kcal, 0) : (history[day.key] ?? 0),
  }));
  const logged = rows.filter((row) => row.kcal > 0);
  const average = logged.length
    ? Math.round(logged.reduce((n, row) => n + row.kcal, 0) / logged.length)
    : 0;
  return (
    <section className="mb-3 rounded-3xl border border-line bg-surface px-4 py-3">
      <h2 className="font-display text-xl tracking-tight">Week</h2>
      <p className="text-sm text-muted">
        {logged.length === 0
          ? "No meals logged in the last 7 days."
          : `Average ${average} kcal on days you logged. Goal is ${goal}.`}
      </p>
      <ul className="mt-3 space-y-2">
        {rows.map((row) => (
          <li key={row.key} className="flex items-center justify-between text-sm">
            <span>{row.label}</span>
            <span className={row.kcal > goal ? "text-danger" : "text-ink"}>
              {row.kcal > 0 ? `${row.kcal} kcal` : "—"}
            </span>
          </li>
        ))}
      </ul>
    </section>
  );
}

function Home() {
  const [messages, setMessages] = useState<ChatMessage[]>([WELCOME]);
  const [draft, setDraft] = useState("");
  const [preview, setPreview] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [goal, setGoal] = useState(2000);
  const [items, setItems] = useState<DayLog[]>([]);
  const [history, setHistory] = useState<Record<string, number>>({});
  const [showWeek, setShowWeek] = useState(false);
  const [ready, setReady] = useState(false);
  const [profile, setProfile] = useState<Profile>({
    age: "",
    weight: "",
    height: "",
    sex: "m",
    goalWeight: "",
  });
  const [planNote, setPlanNote] = useState("");
  const [proteinGoal, setProteinGoal] = useState<number | null>(null);
  const scroller = useRef<HTMLDivElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const boxRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    const stored = readStore();
    setGoal(stored.goal);
    setItems(stored.items);
    setHistory(stored.history);
    try {
      const raw = localStorage.getItem("caloriesnap-profile");
      if (raw) {
        const saved = JSON.parse(raw) as Profile & { protein?: number; note?: string };
        setProfile({
          age: saved.age ?? "",
          weight: saved.weight ?? "",
          height: saved.height ?? "",
          sex: saved.sex === "f" ? "f" : "m",
          goalWeight: saved.goalWeight ?? "",
        });
        if (saved.protein) setProteinGoal(saved.protein);
        if (saved.note) setPlanNote(saved.note);
      }
    } catch {
      /* keep defaults */
    }
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    const historyNext = { ...history, [todayKey()]: items.reduce((n, item) => n + item.kcal, 0) };
    localStorage.setItem(
      "caloriesnap-day",
      JSON.stringify({ goal, day: todayKey(), items, history: historyNext }),
    );
  }, [goal, items, history, ready]);

  useEffect(() => {
    scroller.current?.scrollTo({ top: scroller.current.scrollHeight, behavior: "smooth" });
  }, [messages, busy]);

  async function onFile(file: File | undefined) {
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setError("Choose a photo.");
      return;
    }
    setError(null);
    const dataUrl = await compressImage(file);
    setPreview(dataUrl);
  }

  async function send() {
    const text = draft.trim();
    if (busy || (!text && !preview)) return;
    setBusy(true);
    setError(null);
    const image = preview;
    const userMsg: ChatMessage = {
      id: crypto.randomUUID(),
      role: "user",
      text: text || "Meal photo",
      image: image ?? undefined,
    };
    setMessages((prev) => [...prev, userMsg]);
    setDraft("");
    setPreview(null);
    if (boxRef.current) boxRef.current.style.height = "auto";

    try {
      const result = await analyzeMeal({ data: { text, imageDataUrl: image } });
      setMessages((prev) => [
        ...prev,
        {
          id: crypto.randomUUID(),
          role: "assistant",
          text: result.ok ? result.text : result.error,
        },
      ]);
      if (!result.ok) setError(result.error);
      else {
        const kcal = kcalFrom(result.text);
        if (kcal) {
          setItems((prev) => [
            ...prev,
            { id: crypto.randomUUID(), label: text || "Photo meal", kcal },
          ]);
        }
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : "Something went wrong.";
      setError(message);
      setMessages((prev) => [
        ...prev,
        { id: crypto.randomUUID(), role: "assistant", text: message },
      ]);
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="mx-auto flex h-dvh max-w-2xl flex-col overflow-y-auto px-4 py-4 sm:px-6">
      <header className="mb-3 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="flex size-11 items-center justify-center rounded-2xl bg-primary text-primary-fg">
            <Leaf className="size-5" aria-hidden />
          </div>
          <div>
            <h1 className="font-display text-2xl leading-none tracking-tight">CalorieSnap</h1>
            <p className="text-sm text-muted">Photo in, calorie estimate out</p>
          </div>
        </div>
        <div className="flex gap-2">
          <button
            type="button"
            className="flex h-11 items-center gap-2 rounded-2xl border border-line bg-surface px-3 text-sm text-ink"
            onClick={() => setShowWeek((open) => !open)}
          >
            <BarChart3 className="size-4" aria-hidden />
            Week
          </button>
          <button
            type="button"
            className="flex size-11 items-center justify-center rounded-2xl border border-line bg-surface text-ink"
            aria-label="Clear chat"
            onClick={() => {
              setMessages([WELCOME]);
              setError(null);
            }}
          >
            <Trash2 className="size-4" />
          </button>
        </div>
      </header>

      {showWeek ? <WeekPanel goal={goal} items={items} history={history} /> : null}

      <section className="mb-3 rounded-3xl border border-line bg-surface px-4 py-3">
        <div className="flex items-end justify-between gap-3">
          <div>
            <p className="text-sm text-muted">Today</p>
            <p className="font-display text-3xl leading-none tracking-tight">
              {items.reduce((n, item) => n + item.kcal, 0)}
              <span className="ml-1 text-base text-muted">/ {goal} kcal</span>
            </p>
            {proteinGoal ? (
              <p className="mt-1 text-sm text-muted">Protein target {proteinGoal} g</p>
            ) : null}
          </div>
        </div>
        <form
          className="mt-3 grid grid-cols-2 gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            const next = targets(profile);
            if (!next) {
              setError("Enter age, height, current weight, and a lower goal weight in kg.");
              return;
            }
            setError(null);
            setGoal(next.kcal);
            setProteinGoal(next.protein);
            setPlanNote(next.note);
            localStorage.setItem(
              "caloriesnap-profile",
              JSON.stringify({ ...profile, protein: next.protein, note: next.note }),
            );
          }}
        >
          <label className="text-sm text-muted">
            Age
            <input
              inputMode="numeric"
              value={profile.age}
              onChange={(e) => setProfile({ ...profile, age: e.target.value })}
              className="mt-1 block w-full rounded-xl border border-line bg-bg px-3 py-2 text-ink"
            />
          </label>
          <label className="text-sm text-muted">
            Weight (kg)
            <input
              inputMode="decimal"
              value={profile.weight}
              onChange={(e) => setProfile({ ...profile, weight: e.target.value })}
              className="mt-1 block w-full rounded-xl border border-line bg-bg px-3 py-2 text-ink"
            />
          </label>
          <label className="text-sm text-muted">
            Height (cm)
            <input
              inputMode="decimal"
              value={profile.height}
              onChange={(e) => setProfile({ ...profile, height: e.target.value })}
              className="mt-1 block w-full rounded-xl border border-line bg-bg px-3 py-2 text-ink"
            />
          </label>
          <label className="text-sm text-muted">
            Goal weight (kg)
            <input
              inputMode="decimal"
              value={profile.goalWeight}
              onChange={(e) => setProfile({ ...profile, goalWeight: e.target.value })}
              className="mt-1 block w-full rounded-xl border border-line bg-bg px-3 py-2 text-ink"
            />
          </label>
          <div className="text-sm text-muted">
            Gender
            <div className="mt-1 flex gap-2">
              <button
                type="button"
                className={
                  profile.sex === "m"
                    ? "h-11 flex-1 rounded-xl bg-primary text-primary-fg"
                    : "h-11 flex-1 rounded-xl border border-line bg-bg text-ink"
                }
                onClick={() => setProfile({ ...profile, sex: "m" })}
              >
                Male
              </button>
              <button
                type="button"
                className={
                  profile.sex === "f"
                    ? "h-11 flex-1 rounded-xl bg-primary text-primary-fg"
                    : "h-11 flex-1 rounded-xl border border-line bg-bg text-ink"
                }
                onClick={() => setProfile({ ...profile, sex: "f" })}
              >
                Female
              </button>
            </div>
          </div>
          <button
            type="submit"
            className="col-span-2 h-11 rounded-xl bg-ink text-user-fg"
          >
            Make my 3-month plan
          </button>
        </form>
        {planNote ? <p className="mt-3 text-sm text-ink">{planNote}</p> : null}
        {items.length > 0 ? (
          <ul className="mt-3 space-y-1 text-sm text-muted">
            {items.slice(-3).map((item) => (
              <li key={item.id} className="flex justify-between gap-3">
                <span className="truncate">{item.label}</span>
                <span>{item.kcal}</span>
              </li>
            ))}
          </ul>
        ) : (
          <p className="mt-2 text-sm text-muted">No meals logged yet today.</p>
        )}
      </section>

      <div
        ref={scroller}
        className="min-h-72 shrink-0 space-y-3 overflow-y-auto pb-3"
      >
        {messages.map((msg) => (
          <article
            key={msg.id}
            className={
              msg.role === "user"
                ? "ml-10 rounded-3xl rounded-br-md bg-user px-4 py-3 text-user-fg"
                : "mr-8 rounded-3xl rounded-bl-md border border-line bg-surface px-4 py-3 text-ink"
            }
          >
            {msg.image ? (
              <img
                src={msg.image}
                alt="Meal you uploaded"
                className="mb-2 max-h-52 w-full rounded-2xl object-cover"
              />
            ) : null}
            <p className="whitespace-pre-wrap text-[15px] leading-relaxed">{msg.text}</p>
          </article>
        ))}
        {busy ? (
          <p className="mr-8 rounded-3xl border border-line bg-surface px-4 py-3 text-sm text-muted">
            Looking at the meal…
          </p>
        ) : null}
      </div>

      <form
        className="sticky bottom-0 rounded-3xl border border-line bg-surface p-3 shadow-sm"
        onSubmit={(e) => {
          e.preventDefault();
          void send();
        }}
      >
        {preview ? (
          <div className="relative mb-3 inline-block">
            <img src={preview} alt="Selected meal" className="h-20 w-20 rounded-2xl object-cover" />
            <button
              type="button"
              className="absolute -top-2 -right-2 flex size-7 items-center justify-center rounded-full bg-ink text-user-fg"
              aria-label="Remove photo"
              onClick={() => setPreview(null)}
            >
              <X className="size-3.5" />
            </button>
          </div>
        ) : null}
        <div className="flex items-end gap-2">
          <button
            type="button"
            className="flex size-11 shrink-0 items-center justify-center rounded-2xl bg-bg text-ink"
            aria-label="Upload meal photo"
            onClick={() => fileRef.current?.click()}
          >
            <Camera className="size-5" />
          </button>
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => {
              void onFile(e.target.files?.[0]);
              e.target.value = "";
            }}
          />
          <textarea
            ref={boxRef}
            rows={1}
            value={draft}
            placeholder="Describe the meal, or just send a photo"
            className="max-h-32 min-h-11 flex-1 resize-none bg-transparent px-1 py-2.5 text-[15px] outline-none placeholder:text-muted"
            onChange={(e) => {
              setDraft(e.target.value);
              e.target.style.height = "auto";
              e.target.style.height = `${Math.min(e.target.scrollHeight, 128)}px`;
            }}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                void send();
              }
            }}
          />
          <button
            type="submit"
            disabled={busy || (!draft.trim() && !preview)}
            className="flex size-11 shrink-0 items-center justify-center rounded-2xl bg-primary text-primary-fg disabled:opacity-40"
            aria-label="Send"
          >
            <Send className="size-4" />
          </button>
        </div>
        {error ? <p className="mt-2 px-1 text-sm text-danger">{error}</p> : null}
        <p className="mt-2 px-1 text-xs text-muted">Estimates only. Not medical advice.</p>
      </form>
    </main>
  );
}

function compressImage(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("Could not read that photo."));
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const max = 1024;
        const scale = Math.min(1, max / Math.max(img.width, img.height));
        const canvas = document.createElement("canvas");
        canvas.width = Math.round(img.width * scale);
        canvas.height = Math.round(img.height * scale);
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          reject(new Error("Could not prepare that photo."));
          return;
        }
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL("image/jpeg", 0.72));
      };
      img.onerror = () => reject(new Error("That file is not a usable photo."));
      img.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  });
}
