import { createServerFn } from "@tanstack/react-start";

const SYSTEM = `You are CalorieSnap, a nutrition assistant.
Estimate calories from a meal photo and/or a short description.
Reply in plain text (no markdown tables). Include:
1) What you see (foods and a reasonable portion guess)
2) Estimated calories (a single number plus a short range)
3) Protein, carbs, and fat in grams
4) One practical tip
Be honest when the photo is unclear or portion size is uncertain.
This is an estimate, not medical advice. Keep the reply under 180 words.`;

type AnalyzeInput = {
  text: string;
  imageDataUrl: string | null;
};

type Food = { name: string; kcal: number; p: number; c: number; f: number };

const FOODS: Array<Food & { keys: string[] }> = [
  { keys: ["bagel"], name: "plain bagel", kcal: 280, p: 11, c: 55, f: 2 },
  { keys: ["egg"], name: "egg", kcal: 78, p: 6, c: 1, f: 5 },
  { keys: ["toast", "bread slice", "slice of bread"], name: "slice of bread", kcal: 80, p: 3, c: 14, f: 1 },
  { keys: ["avocado"], name: "avocado half", kcal: 120, p: 1, c: 6, f: 11 },
  { keys: ["banana"], name: "banana", kcal: 105, p: 1, c: 27, f: 0 },
  { keys: ["apple"], name: "apple", kcal: 95, p: 0, c: 25, f: 0 },
  { keys: ["rice"], name: "cup of cooked rice", kcal: 205, p: 4, c: 45, f: 0 },
  { keys: ["chicken"], name: "chicken breast", kcal: 280, p: 52, c: 0, f: 6 },
  { keys: ["salmon"], name: "salmon fillet", kcal: 360, p: 34, c: 0, f: 22 },
  { keys: ["beef", "steak"], name: "beef portion", kcal: 420, p: 42, c: 0, f: 28 },
  { keys: ["burger", "hamburger", "cheeseburger"], name: "burger", kcal: 540, p: 28, c: 40, f: 28 },
  { keys: ["fries", "french fries"], name: "side of fries", kcal: 365, p: 4, c: 48, f: 17 },
  { keys: ["pizza"], name: "pizza slice", kcal: 285, p: 12, c: 36, f: 10 },
  { keys: ["pasta"], name: "plate of pasta", kcal: 420, p: 14, c: 70, f: 9 },
  { keys: ["salad"], name: "side salad", kcal: 150, p: 4, c: 12, f: 9 },
  { keys: ["yogurt", "yoghurt"], name: "yogurt cup", kcal: 150, p: 12, c: 18, f: 3 },
  { keys: ["oat", "oatmeal"], name: "bowl of oatmeal", kcal: 250, p: 8, c: 42, f: 5 },
  { keys: ["coffee"], name: "coffee with milk", kcal: 40, p: 2, c: 4, f: 2 },
  { keys: ["soda", "cola", "coke"], name: "can of soda", kcal: 140, p: 0, c: 39, f: 0 },
  { keys: ["beer"], name: "beer", kcal: 150, p: 1, c: 13, f: 0 },
  { keys: ["cheese"], name: "cheese slice", kcal: 110, p: 7, c: 1, f: 9 },
  { keys: ["bacon"], name: "two bacon strips", kcal: 90, p: 6, c: 0, f: 7 },
  { keys: ["potato"], name: "potato", kcal: 160, p: 4, c: 36, f: 0 },
  { keys: ["bean"], name: "cup of beans", kcal: 220, p: 15, c: 40, f: 1 },
  { keys: ["taco"], name: "taco", kcal: 210, p: 10, c: 18, f: 10 },
  { keys: ["burrito"], name: "burrito", kcal: 650, p: 28, c: 70, f: 28 },
  { keys: ["sandwich"], name: "sandwich", kcal: 420, p: 22, c: 40, f: 18 },
  { keys: ["ice cream"], name: "scoop of ice cream", kcal: 210, p: 4, c: 24, f: 11 },
  { keys: ["chocolate"], name: "chocolate bar", kcal: 230, p: 3, c: 26, f: 13 },
  { keys: ["croissant"], name: "croissant", kcal: 230, p: 5, c: 26, f: 12 },
];

function localEstimate(text: string): string | null {
  const lower = text.toLowerCase();
  const hits: Food[] = [];
  for (const food of FOODS) {
    if (food.keys.some((key) => lower.includes(key))) {
      const count = leadingCount(lower, food.keys);
      for (let i = 0; i < count; i++) hits.push(food);
    }
  }
  if (hits.length === 0) return null;
  const kcal = hits.reduce((n, f) => n + f.kcal, 0);
  const p = hits.reduce((n, f) => n + f.p, 0);
  const c = hits.reduce((n, f) => n + f.c, 0);
  const f = hits.reduce((n, f) => n + f.f, 0);
  const names = hits.map((h) => h.name).join(", ");
  const low = Math.round(kcal * 0.85);
  const high = Math.round(kcal * 1.2);
  return [
    `From your description: ${names}.`,
    `Estimated calories: ${kcal} kcal (about ${low}–${high}).`,
    `Protein ${p}g, carbs ${c}g, fat ${f}g.`,
    `This uses typical portions, not a photo reading. Weighing the plate would be more accurate.`,
    `Estimate only, not medical advice.`,
  ].join("\n");
}

function leadingCount(text: string, keys: string[]): number {
  for (const key of keys) {
    const match = text.match(new RegExp(`(\\d+)\\s+${key}`));
    if (match) return Math.min(6, Number(match[1]) || 1);
    if (new RegExp(`\\b(two|a pair of)\\s+${key}`).test(text)) return 2;
    if (new RegExp(`\\bthree\\s+${key}`).test(text)) return 3;
  }
  return 1;
}

function friendlyApiError(status: number, body: string): string {
  if (body.includes("spending-limit") || body.includes("run out of credits")) {
    return "The photo reader is out of Grok credits right now.";
  }
  return `The photo reader failed (${status}).`;
}

export const analyzeMeal = createServerFn({ method: "POST" })
  .validator((input: AnalyzeInput) => {
    const text = (input.text ?? "").trim().slice(0, 800);
    const imageDataUrl = input.imageDataUrl ?? null;
    if (!text && !imageDataUrl) {
      throw new Error("Add a photo or describe the meal.");
    }
    if (imageDataUrl && imageDataUrl.length > 1_800_000) {
      throw new Error("That photo is too large. Try a smaller one.");
    }
    if (imageDataUrl && !imageDataUrl.startsWith("data:image/")) {
      throw new Error("Only image uploads are supported.");
    }
    return { text, imageDataUrl };
  })
  .handler(async ({ data }) => {
    const apiKey = process.env.XAI_API_KEY;
    const fallback = data.text ? localEstimate(data.text) : null;

    if (!apiKey) {
      if (fallback) return { ok: true as const, text: fallback };
      return {
        ok: false as const,
        error: data.imageDataUrl
          ? "Photo reading is unavailable. Describe the meal in words and I will estimate it."
          : "I don’t recognize those foods yet. Try naming them, like “2 eggs and toast”.",
      };
    }

    const content: Array<
      | { type: "text"; text: string }
      | { type: "image_url"; image_url: { url: string; detail: "low" } }
    > = [
      {
        type: "text",
        text: data.text || "Estimate the calories in this meal photo.",
      },
    ];
    if (data.imageDataUrl) {
      content.push({
        type: "image_url",
        image_url: { url: data.imageDataUrl, detail: "low" },
      });
    }

    try {
      const res = await fetch("https://api.x.ai/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: "grok-4.5",
          temperature: 0.3,
          max_tokens: 450,
          messages: [
            { role: "system", content: SYSTEM },
            { role: "user", content },
          ],
        }),
      });

      if (!res.ok) {
        const raw = await res.text().catch(() => "");
        if (fallback) return { ok: true as const, text: fallback };
        const why = friendlyApiError(res.status, raw);
        return {
          ok: false as const,
          error: data.imageDataUrl
            ? `${why} Type what is on the plate and I will estimate from that.`
            : `${why} Name the foods, like “chicken and rice”.`,
        };
      }

      const body = (await res.json()) as {
        choices?: { message?: { content?: string } }[];
      };
      const text = body.choices?.[0]?.message?.content?.trim();
      if (text) return { ok: true as const, text };
    } catch {
      if (fallback) return { ok: true as const, text: fallback };
    }

    if (fallback) return { ok: true as const, text: fallback };
    return {
      ok: false as const,
      error: "No estimate came back. Describe the foods and try again.",
    };
  });
