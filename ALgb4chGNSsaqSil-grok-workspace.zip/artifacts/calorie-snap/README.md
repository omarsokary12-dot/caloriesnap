# CalorieSnap – AI Meal Calorie Chat

A modern web app that lets anyone estimate meal calories by uploading a photo or describing the food in a chatbot interface.

## Features

- Beautiful chat interface (mobile-friendly)
- Photo upload of meals
- Text description support
- Dark / Light mode
- Typing indicator & smooth animations
- **Real GPT-4o Vision analysis** (connected)

## How to run

Just open `index.html` in any modern browser.  
No build step or server required.

```bash
# Or serve it locally
npx serve .
```

## Current Status: Real GPT-4o Vision Connected

The app is now connected to **OpenAI GPT-4o** with vision capabilities.

### ⚠️ CRITICAL SECURITY WARNING

Your OpenAI API key is currently stored **in the frontend JavaScript**.  
Anyone who opens the page can view the source and steal the key.

**Do this immediately after testing:**
1. Go to https://platform.openai.com/api-keys
2. Revoke / delete the key you pasted
3. Create a new key only when you need it again
4. For real production use → move the API call to a backend server so the key stays secret

## Disclaimer

Calorie estimates from photos are **approximate**.  
Portion size, cooking method, and hidden ingredients make exact numbers impossible from a single photo.  
This is **not medical or professional dietary advice**.

---

Built with plain HTML + Tailwind CSS + vanilla JS + OpenAI GPT-4o.
